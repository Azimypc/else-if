﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfSteatment
{
    class Program
    {
        static void Main(string[] args)
        {
            string Name = "karin";
            string passwort = "74659";

            Console.WriteLine(Name + Environment.NewLine + passwort);
            Console.ReadKey();
        }
    }
}
