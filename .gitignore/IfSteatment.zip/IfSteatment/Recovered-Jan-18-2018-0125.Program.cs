﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfSteatment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bitte schreiben Sie ihre name.");

            string Name = Console.ReadLine();

            Console.WriteLine("bitte Schreiben Sie ihre password");

            string passwort = Console.ReadLine();

            string UserName = "karin";
            string userpassword = "123456";

            if (Name == UserName)
            {
                Console.WriteLine("Deine Name ist passt");


            }
            if (Name != UserName)
            {
                Console.WriteLine("Deine name ist Falsch");
            }

        }
    }
}
